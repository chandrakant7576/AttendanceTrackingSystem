package dao;

import db.DBConnect;
import model.AttendanceLog;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.*;

public class AttendanceDAO {

    public void clockIn(int empId) {
        try (Connection conn = DBConnect.getConnection()) {
            String sql = "INSERT INTO attendance_logs (employee_id, clock_in) VALUES (?, NOW())";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, empId);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void clockOut(int empId) {
        try (Connection conn = DBConnect.getConnection()) {
            String sql = "UPDATE attendance_logs SET clock_out = NOW() WHERE employee_id=? AND clock_out IS NULL";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, empId);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ✅ New Method
    public List<AttendanceLog> getAllLogs() {
        List<AttendanceLog> logs = new ArrayList<>();
        try (Connection conn = DBConnect.getConnection()) {
            String sql = "SELECT * FROM attendance_logs ORDER BY clock_in DESC";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                AttendanceLog log = new AttendanceLog();
                log.setId(rs.getInt("id"));
                log.setEmployeeId(rs.getInt("employee_id"));
                Timestamp in = rs.getTimestamp("clock_in");
                Timestamp out = rs.getTimestamp("clock_out");
                if (in != null) log.setClockIn(in.toLocalDateTime());
                if (out != null) log.setClockOut(out.toLocalDateTime());
                logs.add(log);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return logs;
    }
}
