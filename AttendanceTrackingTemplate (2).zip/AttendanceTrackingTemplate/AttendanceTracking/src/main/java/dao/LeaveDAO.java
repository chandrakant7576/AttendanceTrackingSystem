package dao;

import db.DBConnect;
import model.LeaveRequest;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LeaveDAO {

    public void applyLeave(int empId, String date, String type, String reason) {
        try (Connection conn = DBConnect.getConnection()) {
            String sql = "INSERT INTO leave_requests (employee_id, leave_date, leave_type, reason, status) VALUES (?, ?, ?, ?, 'Pending')";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, empId);
            ps.setDate(2, java.sql.Date.valueOf(date));  // Ensure String date is in yyyy-MM-dd format
            ps.setString(3, type);
            ps.setString(4, reason);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<LeaveRequest> getAllPendingLeaves() {
        List<LeaveRequest> list = new ArrayList<>();
        try (Connection conn = DBConnect.getConnection()) {
            String sql = "SELECT * FROM leave_requests WHERE status='Pending'";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                LeaveRequest lr = new LeaveRequest();
                lr.setId(rs.getInt("id"));
                lr.setEmployeeId(rs.getInt("employee_id"));
                lr.setLeaveDate(rs.getDate("leave_date").toLocalDate());  // Converts java.sql.Date to LocalDate
                lr.setLeaveType(rs.getString("leave_type"));
                lr.setReason(rs.getString("reason"));
                lr.setStatus(rs.getString("status"));
                list.add(lr);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public void updateLeaveStatus(int leaveId, String status) {
        try (Connection conn = DBConnect.getConnection()) {
            String sql = "UPDATE leave_requests SET status = ? WHERE id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, status); // "Approved" or "Rejected"
            ps.setInt(2, leaveId);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
