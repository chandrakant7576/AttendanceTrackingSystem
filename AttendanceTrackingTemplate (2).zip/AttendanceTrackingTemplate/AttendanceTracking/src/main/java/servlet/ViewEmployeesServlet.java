package servlet;

import dao.EmployeeDAO;
import model.Employee;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/view-employees")
public class ViewEmployeesServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        EmployeeDAO dao = new EmployeeDAO();
        List<Employee> employees = dao.getAllEmployees();
        req.setAttribute("employee_List", employees);
        RequestDispatcher dispatcher = req.getRequestDispatcher("viewEmployees.jsp");
        dispatcher.forward(req, res);
    }
}

