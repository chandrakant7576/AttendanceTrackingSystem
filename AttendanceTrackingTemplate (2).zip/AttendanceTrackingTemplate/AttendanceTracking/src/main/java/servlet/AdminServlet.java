package servlet;

import dao.EmployeeDAO;
import dao.LeaveDAO;
import model.Employee;
import model.LeaveRequest;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;
import java.io.IOException;
import java.util.List;

@WebServlet("/AdminServlet")
public class AdminServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        String action = req.getParameter("action");

        if ("employees".equals(action)) {
            EmployeeDAO dao = new EmployeeDAO();
            List<Employee> list = dao.getAllEmployees();
            req.setAttribute("list", list);
            req.getRequestDispatcher("employee_list.jsp").forward(req, res);
        } else if ("leaves".equals(action)) {
            LeaveDAO dao = new LeaveDAO();
            List<LeaveRequest> list = dao.getAllPendingLeaves();
            req.setAttribute("list", list);
            req.getRequestDispatcher("approve_leave.jsp").forward(req, res);
        }
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        int leaveId = Integer.parseInt(req.getParameter("leaveId"));
        String status = req.getParameter("status");
        LeaveDAO dao = new LeaveDAO();
        dao.updateLeaveStatus(leaveId, status);
        res.sendRedirect("AdminServlet?action=leaves");
    }
}
