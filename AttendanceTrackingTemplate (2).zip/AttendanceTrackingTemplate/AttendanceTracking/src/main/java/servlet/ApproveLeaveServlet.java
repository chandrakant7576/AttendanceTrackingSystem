package servlet;
import dao.LeaveDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
@WebServlet("/approve-leave")
public class ApproveLeaveServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        int leaveId = Integer.parseInt(req.getParameter("leaveId"));
        String action = req.getParameter("action");

        LeaveDAO dao = new LeaveDAO();
        if ("approve".equals(action)) {
            dao.updateLeaveStatus(leaveId, "Approved");
        } else if ("reject".equals(action)) {
            dao.updateLeaveStatus(leaveId, "Rejected");
        }

        res.sendRedirect("pending-leaves");
    }
}
