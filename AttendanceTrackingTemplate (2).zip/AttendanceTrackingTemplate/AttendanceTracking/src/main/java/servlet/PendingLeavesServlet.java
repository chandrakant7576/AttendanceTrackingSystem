package servlet;

import dao.LeaveDAO;
import model.LeaveRequest;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/pending-leaves")
public class PendingLeavesServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        LeaveDAO dao = new LeaveDAO();
        List<LeaveRequest> list = dao.getAllPendingLeaves();
        req.setAttribute("pendingLeaves", list);
        RequestDispatcher rd = req.getRequestDispatcher("pending_leaves.jsp");
        rd.forward(req, res);
    }
}