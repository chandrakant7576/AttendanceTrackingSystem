package servlet;

import dao.LeaveDAO;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class LeaveRequestServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        int empId = Integer.parseInt(req.getParameter("employee_id"));
        String date = req.getParameter("leave_date");
        String type = req.getParameter("leave_type");
        String reason = req.getParameter("reason");

        LeaveDAO dao = new LeaveDAO();
        dao.applyLeave(empId, date, type, reason);

        res.sendRedirect("dashboard.jsp");
    }
}
