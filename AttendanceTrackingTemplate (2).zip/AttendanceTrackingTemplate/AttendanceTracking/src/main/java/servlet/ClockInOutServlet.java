package servlet;

import dao.AttendanceDAO;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class ClockInOutServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        int empId = Integer.parseInt(req.getParameter("employee_id"));
        String action = req.getParameter("action");

        AttendanceDAO dao = new AttendanceDAO();
        if ("clockin".equals(action)) {
            dao.clockIn(empId);
        } else if ("clockout".equals(action)) {
            dao.clockOut(empId);
        }

        res.sendRedirect("dashboard.jsp");
    }
}
