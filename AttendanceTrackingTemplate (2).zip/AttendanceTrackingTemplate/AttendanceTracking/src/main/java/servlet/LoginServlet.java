package servlet;

import dao.EmployeeDAO;
import model.Employee;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String email = req.getParameter("email");
        String password = req.getParameter("password");

        EmployeeDAO dao = new EmployeeDAO();
        Employee emp = dao.validateLogin(email, password); // Updated to return Employee object

        if (emp != null) {
            HttpSession session = req.getSession();
            session.setAttribute("email", emp.getEmail());
            session.setAttribute("name", emp.getName());
            session.setAttribute("role", emp.getRole());
            session.setAttribute("employee_id", emp.getId()); // Ensure ID is fetched too

            res.sendRedirect("dashboard.jsp"); // Keep or update as needed
        } else {
            res.sendRedirect("login.jsp?error=1");
        }
    }
}
